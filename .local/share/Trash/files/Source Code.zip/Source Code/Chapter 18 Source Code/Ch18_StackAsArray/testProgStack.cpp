//Program to test the various operations of a stack
  
#include <iostream>
#include "myStack.h"
 
using namespace std; 
 
int main()
{
	cout << "Example 18-1 shows how a stack is used." << endl;

	return 0;
}
