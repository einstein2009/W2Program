//Test Program linked queue 
  
#include <iostream>
#include "linkedQueue.h"
  
using namespace std; 
 
int main()
{
    cout << "See Example 18-5." << endl;

    return 0;
}