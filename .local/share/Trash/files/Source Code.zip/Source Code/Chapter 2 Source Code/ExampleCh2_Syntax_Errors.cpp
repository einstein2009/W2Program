#include <iostream> 
 
using namespace std;
 
int main() 
{ 
    int num  

    num = 18; 

    tempNum = 2 * num;

    cout << "Num = " << num << ", tempNum = " < tempNum << endl; 

    return ;
}
