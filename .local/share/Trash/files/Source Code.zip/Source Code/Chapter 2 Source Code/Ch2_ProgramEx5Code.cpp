
#include <iostream> 
{
    int main()

    cout << "Enter the radius: ";
    cin >> radius;
    cout << endl;

    double radius; 
    double area;

    using namespace std;

    return 0;

    cout << "Area = " << area << endl;

    area = PI * radius * radius;

    circumference = 2 * PI * radius;
        
    cout << "Circumference = " << circumference << endl;

    const double PI = 3.14;

    double circumference;
}