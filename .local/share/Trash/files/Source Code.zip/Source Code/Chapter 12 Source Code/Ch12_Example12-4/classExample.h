//Header file classExample.h
     
class classExample
{
public:
	void setX(int a);
		//Function to set the value of x
		//Postcondition: x = a;
	void print() const;
		//Function to output the value of x

private:
	int x;
};
